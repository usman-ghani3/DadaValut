import React from 'react';
import {Header} from "../../components";


function Home() {
  return (
      <>
          <Header/>
      </>
  );
}

export default Home;
