import React from "react";
import {
    Box,
    Flex,
    Heading,
    Text
} from "@chakra-ui/react";


function Dashboard() {
  return (
      <>
          <Box backgroundColor="#F2F2F2" minH={'136'} py={15} px={12}>
              <Flex>
                  <Box flex="1">
                      <Heading color={'#4D4D4D'} fontWeight="700" fontSize="30px">Dashboard</Heading>
                      <Text color={'#808080'} fontWeight="400" fontSize="14px">Updated 5 seconds ago</Text>
                  </Box>
              </Flex>
          </Box>
      </>
    
  );
}

export default Dashboard;
